<?
include_once("config.php");
flushMemberSession();
header('Location: index.php');
?>
