This is the source code for a Sitepoint article:
